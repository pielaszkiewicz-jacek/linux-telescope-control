#ifndef __tlinAttitudeIteration_hpp__
#define __tlinAttitudeIteration_hpp__

#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <list>
#include <map>
#include <memory>
#include <mutex>
#include <utility>
#include <vector>

#include "tlinAttitudeMeasurment.hpp"
#include <tlinsAstroObject.hpp>

//
// --- Pojedyncza iteracja
//
namespace attitude
{

class tlinAttitudeIteration;
class tlinAttitudeIterations;

class tlinsAttitudeProcessorState {
  public:
	virtual Eigen::Matrix3d getAttitutude()         = 0;
	virtual Eigen::Matrix3d getInvertedAttitutude() = 0;
	virtual ~tlinsAttitudeProcessorState() = default;
};

class tlinsAttitudeProcessor {
  public:
	// Procesowanie pojedynczej biezacej iteracji
	virtual std::shared_ptr<tlinsAttitudeProcessorState>
	iteration(std::shared_ptr<tlinsAttitudeProcessorState> currentState,
	          std::shared_ptr<tlinAttitudeIteration> curIter,
	          std::shared_ptr<tlinAttitudeIteration> prevIter,
	          std::shared_ptr<tlinAttitudeIteration> first) = 0;

	virtual std::string name() = 0;

	virtual bool isReqursive() = 0;

	// Procesowanie calego batcha iteracji
	virtual std::shared_ptr<tlinsAttitudeProcessorState> compute(tlinAttitudeIterations &iters) = 0;

	virtual ~tlinsAttitudeProcessor() = default;
};

class tlinAttitudeIteration {
  public:
	EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  private:
	// Mapa stanów poszczegolnych algorytmow wyliczajacych mmacierz transformacji
	std::vector<std::shared_ptr<tlinsAttitudeProcessor>> procesors;
	std::map<std::string, std::shared_ptr<tlinsAttitudeProcessorState>> statesMap;

  private:
	// Pomiar zwiazany z iteracja
	tlinAttitudeMeasurement measurment;

	// Omega_K
	Eigen ::Matrix4d Omega_k;
	Eigen ::Matrix4d FI_k;

	//
	// Macierz K
	//
	Eigen::Matrix3d B;
	Eigen::Matrix3d S;
	Eigen::Vector3d Z;
	double          sigma;
	double          lambda;
	Eigen::Matrix4d K;
	Eigen::Vector3d Q;

	Eigen::Matrix3d optimalASimple;
	Eigen::Matrix3d optimalASimpleInversed;

	Eigen::Matrix3d optimalATriad;
	Eigen::Matrix3d optimalATriadInversed;

	Eigen::Matrix3d B_k1;
	Eigen::Matrix3d S_k1;
	Eigen::Vector3d Z_k1;
	double          sigma_k1;
	Eigen::Matrix4d deltaK_k1;

	//
	// Macierz W
	//
	Eigen ::Matrix3d W_B_k1;
	Eigen ::Matrix3d W_S_k1;
	Eigen ::Vector3d W_Z_k1;
	double           W_kappa_k1;
	Eigen ::Matrix4d W_k1;

	//
	// Obiekty zwiazane z czasem
	//
	Eigen::Matrix4d P_k1_k1;
	Eigen::Matrix4d P_k1_k;

	Eigen::Matrix4d K_k1_k1;
	Eigen::Matrix4d K_k1_k;

	double rho_k1;
	double m_k1;
	double mi_k1;
	double eta_k1;

	Eigen::Matrix4d R_k1;
	Eigen::Matrix4d Q_k1;

	Eigen::Matrix3d optimalA;
	Eigen::Matrix3d optimalAInversed;

  private:
	void compute_QUEST(std ::shared_ptr<tlinAttitudeIteration> prevIter);
	void compute_TRIAD(std ::shared_ptr<tlinAttitudeIteration> prevIter);

  public:
	const tlinAttitudeMeasurement &getMeasurment() const;

	Eigen::Matrix3d getOptimalA();
	Eigen::Matrix3d getOptimalAInversed();

	Eigen::Matrix3d getOptimalASimple()
	{
		return optimalASimple;
	};

	Eigen::Matrix3d getOptimalASimpleInversed()
	{
		return optimalASimpleInversed;
	};

	Eigen::Matrix3d getOptimalATriad()
	{
		return optimalATriad;
	}

	Eigen::Matrix3d getOptimalATriadInversed()
	{
		return optimalATriadInversed;
	};

	void setOptimalA(const Eigen::Matrix3d &v);
	void setOptimalAInversed(const Eigen::Matrix3d &v);

	const Eigen ::Matrix4d &getOmega_k() const;
	const Eigen ::Matrix4d &getFI_k() const;

	const Eigen ::Matrix3d &getB() const
	{
		return B;
	};

	const Eigen ::Matrix3d &getS() const
	{
		return S;
	};

	const Eigen ::Vector3d &getZ() const
	{
		return Z;
	};

	const Eigen ::Matrix4d &getK() const
	{
		return K;
	};

	const Eigen ::Matrix3d &getB_k1() const;
	const Eigen ::Matrix3d &getS_k1() const;
	const Eigen ::Vector3d &getZ_k1() const;
	const double            getSigma_k1() const;
	const Eigen ::Matrix4d &getDeltaK_k1() const;

	const Eigen ::Matrix3d &getW_B_k1() const;
	const Eigen ::Matrix3d &getW_S_k1() const;
	const Eigen ::Vector3d &getW_Z_k1() const;
	const double            getW_kappa_k1() const;
	const Eigen ::Matrix4d &getW_k1() const;

	const Eigen ::Matrix4d &getP_k1_k1() const;
	const Eigen ::Matrix4d &getP_k1_k() const;

	const Eigen ::Matrix4d &getK_k1_k1() const;
	const Eigen ::Matrix4d &getK_k1_k() const;

	const double getRho_k1() const;
	const double getM_k1() const;
	const double getMi_k1() const;
	const double getEta_k1() const;

	const Eigen ::Matrix4d &getR_k1() const;
	const Eigen ::Matrix4d &getQ_k1() const;

  public:
	// Aktualizacja wagi
	void updateWeight(const double w)
	{
		measurment.setWeight(w);
	};

	// Obliczanie iteracji
	void compute(std ::shared_ptr<tlinAttitudeIteration> prev);
	void computeTimeUpdate(const tlinAttitudeIteration &prev);
	void computeMeasurmentUpdate(const tlinAttitudeIteration &prev);

	// Konstruktor/destruktor klasy/operatory
	tlinAttitudeIteration &operator=(const tlinAttitudeIteration &v) = default;
	tlinAttitudeIteration &operator=(tlinAttitudeIteration &&v) = default;

	tlinAttitudeIteration();
	tlinAttitudeIteration(const tlinAttitudeMeasurement &m);

	tlinAttitudeIteration(const tlinAttitudeIteration &v) = default;
	tlinAttitudeIteration(tlinAttitudeIteration &&v)      = default;
	virtual ~tlinAttitudeIteration();
};

//
// --- Kontener przechowujacy iteracje
//
class tlinAttitudeIterations {
  private:
	// Iteracje
	std::shared_ptr<tlinAttitudeIteration>             firstElement;
	std ::list<std::shared_ptr<tlinAttitudeIteration>> iterations;

	// Aktualna macierz transformacji
	Eigen ::Matrix3d attirtude;

	std ::mutex  mtx;
	unsigned int sizeLimit;
	int          totalCount;

  public:
	// Dodanie iteracji oraz obliczenie aktualnej macierzy obrotu
	void add(const std::shared_ptr<tlinAttitudeIteration> &iter);

	// Licznik iteracji
	const unsigned int size();

	std ::list<std::shared_ptr<tlinAttitudeIteration>>::iterator begin()
	{
		return iterations.begin();
	};

	std ::list<std::shared_ptr<tlinAttitudeIteration>>::iterator end()
	{
		return iterations.end();
	};

	bool isEmpty() const
	{
		return iterations.empty();
	};

	std ::shared_ptr<tlinAttitudeIteration> getLast();
	std ::shared_ptr<tlinAttitudeIteration> getFirst();
	std ::shared_ptr<tlinAttitudeIteration> getSecond();

	void updateWeights();

	// Obliczenia
	const Eigen::Matrix3d &getAttitude();

	tlinAttitudeIterations(const unsigned int maxSize);
	virtual ~tlinAttitudeIterations();
};

}; // namespace attitude

#endif